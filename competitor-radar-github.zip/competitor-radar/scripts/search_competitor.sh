#!/bin/bash
# Competitor Radar - Search Script
# Usage: ./search_competitor.sh <competitor_name> [query_suffix]

set -e

TAVILY_API_KEY="${TAVILY_API_KEY:-}"
COMPETITOR="${1:-}"
QUERY_SUFFIX="${2:-}"
DATE=$(date +%Y-%m-%d)

if [ -z "$TAVILY_API_KEY" ]; then
    echo "Error: TAVILY_API_KEY not set" >&2
    exit 1
fi

if [ -z "$COMPETITOR" ]; then
    echo "Usage: $0 <competitor_name> [query_suffix]"
    echo "Example: $0 zhipu 'GLM new model'"
    exit 1
fi

# Build search query based on competitor
case "$COMPETITOR" in
    zhipu|智谱)
        QUERY="智谱AI Zhipu GLM ${QUERY_SUFFIX} ${DATE} 2026"
        ;;
    openclaw|clawhub)
        QUERY="OpenClaw Clawhub ${QUERY_SUFFIX} ${DATE} 2026"
        ;;
    claude|anthropic)
        QUERY="Claude AI Anthropic ${QUERY_SUFFIX} ${DATE} 2026"
        ;;
    *)
        QUERY="${COMPETITOR} ${QUERY_SUFFIX} ${DATE}"
        ;;
esac

# Perform search
curl -s -X POST https://api.tavily.com/search \
  -H "Content-Type: application/json" \
  -d "{
    \"api_key\": \"${TAVILY_API_KEY}\",
    \"query\": \"${QUERY}\",
    \"max_results\": 5,
    \"search_depth\": \"advanced\",
    \"include_domains\": [
      \"docs.bigmodel.cn\",
      \"www.zhipuai.cn\",
      \"openclaw.ai\",
      \"clawhub.ai\",
      \"docs.openclaw.ai\",
      \"support.anthropic.com\",
      \"www.anthropic.com\"
    ]
  }" | jq -r '.results[] | select(.score > 0.7) | {
    title: .title,
    url: .url,
    content: .content,
    published_date: .published_date
  }' 2>/dev/null || echo "[]"