#!/bin/bash
# Competitor Radar - Report Generator
# Usage: ./generate_report.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATE=$(date +%Y-%m-%d)
TIME=$(date +%H:%M)

echo "📊 竞品动态雷达 - ${DATE} ${TIME}"
echo ""
echo "---"
echo ""

# Search each competitor
echo "## 一、动态监控"
echo ""

echo "### 智谱 AI"
echo ""
"${SCRIPT_DIR}/search_competitor.sh" zhipu | jq -r '. | "**\(.title)**\n- 来源：\(.url)\n- 摘要：\(.content | split(\".\")[0:2] | join(\".\"))...\n"' 2>/dev/null || echo "暂无新动态"
echo ""

echo "### OpenClaw"
echo ""
"${SCRIPT_DIR}/search_competitor.sh" openclaw | jq -r '. | "**\(.title)**\n- 来源：\(.url)\n- 摘要：\(.content | split(\".\")[0:2] | join(\".\"))...\n"' 2>/dev/null || echo "暂无新动态"
echo ""

echo "### Claude"
echo ""
"${SCRIPT_DIR}/search_competitor.sh" claude | jq -r '. | "**\(.title)**\n- 来源：\(.url)\n- 摘要：\(.content | split(\".\")[0:2] | join(\".\"))...\n"' 2>/dev/null || echo "暂无新动态"
echo ""

echo "---"
echo ""
echo "## 二、商业洞察"
echo ""
echo "（基于动态数据，由 LLM 分析生成）"
echo ""

echo "---"
echo ""
echo "## 三、产品机会"
echo ""
echo "（基于动态数据，由 LLM 分析生成）"
echo ""

echo "---"
echo ""
echo "*本报告由 Competitor Radar 自动生成*"