# Competitor Radar 🎯

AI Agent 竞品动态监控系统 - OpenClaw Skill

## 功能

自动监控 AI Agent 领域核心竞品动态，生成包含来源链接、商业洞察和产品机会的分析报告。

### 监控对象
- **智谱 AI** - GLM 系列模型、API 更新
- **OpenClaw** - 版本更新、生态变化  
- **Claude** - 新模型、企业功能

### 输出格式
1. **动态监控** - 标题、来源链接、时间、摘要
2. **商业洞察** - 策略分析、趋势判断
3. **产品机会** - 短期/中期 actionable 建议

## 安装

```bash
# 下载 skill 文件后安装
openclaw skills install ./competitor-radar.skill
```

## 使用

```bash
# 生成今日简报
openclaw agent --message "运行竞品雷达"

# 监控特定竞品
openclaw agent --message "监控智谱的最新动态"

# 生成周报
openclaw agent --message "生成竞品周报"
```

## 定时任务（自动推送）

```bash
openclaw cron add \
  --name "竞品雷达日报" \
  --cron "0 9 * * 1-5" \
  --message "运行竞品雷达生成简报" \
  --channel feishu \
  --to "你的用户ID"
```

## 技术栈

- Tavily Search API - 高质量搜索
- OpenClaw Skill 框架 - 自动化执行
- Feishu/多平台 - 消息推送

## License

MIT