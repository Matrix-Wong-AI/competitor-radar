# Competitor Radar - 竞品配置参考

## 默认监控对象

### 1. 智谱 AI (Zhipu)

**关键词**：智谱、Zhipu、GLM、ChatGLM、清言

**重点页面**：
- https://docs.bigmodel.cn/cn/update/new-releases
- https://www.zhipuai.cn/
- https://www.z.ai/

**监控重点**：
- 新模型发布（GLM-5、GLM-4 系列）
- API 能力更新
- 定价策略变化
- 生态合作动态

---

### 2. OpenClaw / ClawHub

**关键词**：OpenClaw、Clawhub、龙虾、技能市场

**重点页面**：
- https://clawhub.ai
- https://docs.openclaw.ai
- GitHub: https://github.com/openclaw/openclaw

**监控重点**：
- 版本更新（特别是破坏性变更）
- 新模型支持
- 插件/技能生态变化
- 安全策略更新

---

### 3. Claude (Anthropic)

**关键词**：Claude、Anthropic、Sonnet、Opus、Constitution AI

**重点页面**：
- https://support.anthropic.com/en/articles/12138966-release-notes
- https://www.anthropic.com/news
- https://claude.ai

**监控重点**：
- 新模型发布（Sonnet、Opus 系列）
- API 功能更新
- 安全/对齐研究进展
- 企业功能（Teams、Enterprise）

---

## 扩展监控对象

可根据需要添加：

| 竞品 | 关键词 | 监控重点 |
|------|--------|----------|
| OpenAI | GPT、ChatGPT | 新模型、API更新 |
| 文心一言 | 百度、Ernie | 企业市场策略 |
| 通义千问 | 阿里云、Qwen | 开源模型进展 |
| MiniMax | 稀宇科技 | 语音/多模态能力 |
| Mistral | Mixtral | 开源生态 |
| Gemini | Google | 多模态能力 |

---

## 搜索策略

### 高质量来源优先级

1. **官方渠道**（最高权重）
   - 官方文档 Release Notes
   - 官方博客
   - GitHub Releases

2. **权威媒体**（高权重）
   - 机器之心
   - 量子位
   - TechCrunch
   - The Verge

3. **开发者社区**（中权重）
   - Hacker News
   - Reddit r/LocalLLaMA
   - Twitter/X 官方账号

### 过滤策略

- 排除重复报道（同一事件多个来源只保留官方）
- 排除低信源（无来源说明、明显营销号）
- 优先近7天内容